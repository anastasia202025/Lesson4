public class GameStarter {
    public static void main(String[] args) {
        TicTacToe.start();
    }
}

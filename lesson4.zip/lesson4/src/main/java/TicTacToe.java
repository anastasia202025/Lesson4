import java.util.Random;
import java.util.Scanner;

public class TicTacToe {
    static void start() {
        char[][] field = createField();
        drawField(field);

        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        while (true) {
            doPlayerMove(field);
            if(isDraw(field)) {
                break;
            }
                doAiMove(field);
            if (isDraw(field)){
                break;
            }
        }
    }


    static  boolean isDraw(char[][] field){
        for (int i = 0; i < field.length; i++) {
            for (int j = 0; j < field.length; j++) {
             if ( isCelLFree(field,i,j)){
               return false;
            }
        }

        }
        return true;
    }

  static void doAiMove(char[][]field){
    Random random = new Random();
    int row,col;
    do {
        row = random.nextInt(field.length);
        col = random.nextInt(field.length);
    }while (isCellOccupied(field,row,col));

    field[row][col] = '0';
    drawField(field);
}
    static void doPlayerMove(char[][] field) {
        int row;
        int col;
        do {
            System.out.println("Please input coordinates...");
            row = getCoordinate("row");
            col = getCoordinate("col");
        } while (isCellOccupied(field,row,col));

        field[row][col] = 'X';
        drawField(field);
    }
    static boolean isCelLFree(char[][] field,int row, int col){
        return !isCellOccupied(field,row,col);

    }
    static boolean isCellOccupied(char[][] field,int row, int col){ return field[row][col]!='-';

    }

    static int getCoordinate(String coordType) {
        Scanner scanner = new Scanner(System.in);
        int coord;
        do {
            System.out.printf("Please input %s-coordinate[1-3]...%n",coordType);
            coord=scanner.nextInt()-1;
        }while (coord < 0 || coord>=3);
        return coord;
    }

    static char [][] createField() {
        return new char[][]{
            {'-', '-', '-'},
            {'-', '-', '-'},
            {'-', '-', '-'}
    };

    };

        static void drawField (char[][] field) {
            for (int i=0;i< field.length;i++) {
                for (int j =0;j < field.length;j++){
                    System.out.print(field[i][j]);
                    System.out.print("");
                }
                System.out.println();
            }
            System.out.println();
        }
  }
